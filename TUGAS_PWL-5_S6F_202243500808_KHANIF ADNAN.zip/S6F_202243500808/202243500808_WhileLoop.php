<?php include 'header.php'; ?>
<?php include 'sidebar.php'; ?>

<div class="content">
    <?php
    //inisialisasi nilai awal
    $i = 0;

    while ($i < 10) //lakukan selama memenuhi syarat
    {
        //jalankan blok program
        echo $i;
        $i++;
    }

    //0123456789
    ?>
</div>

<?php include 'footer.php'; ?>