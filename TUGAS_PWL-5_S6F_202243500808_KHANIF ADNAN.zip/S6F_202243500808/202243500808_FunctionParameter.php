<?php include 'header.php'; ?>
<?php include 'sidebar.php'; ?>

<div class="content">
    <div>
        <div>
            <h3>Function Dengan Parameter</h3>

            <div>
                <p>Menambahkan parameter dalam sebuah function diantara ( )</p>

                <div>
                    <h3>Output:</h3>
                    <?php
                    function salam($nama)
                    {
                        echo "Halo $nama<br>";
                    }

                    salam("Agus Pelek");
                    salam("Tatang ZupaZup");
                    ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include 'footer.php'; ?>