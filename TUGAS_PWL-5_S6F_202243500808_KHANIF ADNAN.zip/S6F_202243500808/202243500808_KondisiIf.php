<?php include 'header.php'; ?>
<?php include 'sidebar.php'; ?>

<div class="content">
    <?php
    $nilai = 60;
    if ($nilai >= 50)
        echo "Anda Lulus";
    else
        echo "Anda Tidak Lulus";
    ?>
</div>

<?php include 'footer.php'; ?>