<?php include 'header.php'; ?>
<?php include 'sidebar.php'; ?>

<div class="content">
    <?php
        echo '<p>Hello World!</p>';
    ?>
</div>

<?php include 'footer.php'; ?>