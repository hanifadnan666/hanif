<?php include 'header.php'; ?>
<?php include 'sidebar.php'; ?>

<div class="content">
    <div>
        <div>
            <h3>Function Dengan Parameter Default</h3>

            <div>
                <p>Menambahkan parameter dalam sebuah function diantara ( ) dan menambahkan parameter default</p>

                <div>
                    <h3>Output:</h3>
                    <?php
                    function salam($nama = "PHP")
                    {
                        echo "Halo $nama<br>";
                    }

                    salam("Mahasiswa");
                    salam();
                    ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include 'footer.php'; ?>