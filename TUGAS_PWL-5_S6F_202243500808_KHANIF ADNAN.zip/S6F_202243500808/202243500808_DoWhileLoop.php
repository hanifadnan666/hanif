<?php include 'header.php'; ?>
<?php include 'sidebar.php'; ?>

<div class="content">
    <?php
    //inisialisasi nilai awal
    $i = 0;

    do {

        //jalankan program
        echo $i;
        $i++;
    } while ($i < 10); //ulangi jika memenuhi syarat

    //0123456789
    ?>
</div>

<?php include 'footer.php'; ?>