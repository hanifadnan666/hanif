</div>
<footer class="footer" style="padding: 20px; text-align: center;">
    <ul style="list-style: none; padding: 0; margin: 0;">
        <li style="margin-bottom: 10px;">
            <a href="http://localhost/S6F_202243500808/202243500808_Home.php" style="text-decoration: none;">
                <button style="width: 100%; max-width: 300px; padding: 10px; background-color: rgb(255, 0, 0); color: white; border: none; border-radius: 5px; cursor: pointer;">
                    Home
                </button>
            </a>
        </li>
        <li style="margin-bottom: 10px;">
            <a href="http://localhost/S6F_202243500808/202243500808_About.php" style="text-decoration: none;">
                <button style="width: 100%; max-width: 300px; padding: 10px; background-color: rgb(252, 255, 49); color: black; border: none; border-radius: 5px; cursor: pointer;">
                    About Me
                </button>
            </a>
        </li>
        <li style="margin-bottom: 15px;">
            <a href="http://localhost/S6F_202243500808/202243500808_Contact.php" style="text-decoration: none;">
                <button style="width: 100%; max-width: 300px; padding: 10px; background-color: rgb(0, 55, 235); color: white; border: none; border-radius: 5px; cursor: pointer;">
                    Contact Me
                </button>
            </a>
        </li>
    </ul>

    <p style="margin-top: 20px;"><strong>Tugas PWL By: Khanif Adnan</strong></p>
</footer>
</body>

</html>