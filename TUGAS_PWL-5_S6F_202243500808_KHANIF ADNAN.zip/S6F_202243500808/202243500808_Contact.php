<?php include 'header.php'; ?>
<?php include 'sidebar.php'; ?>

<div style="padding: 20px;">
    <h1 style="font-size: 28px; margin-bottom: 10px;">Mari Terhubung</h1>
    <div style="margin-top: 25px;">
        <p style="font-size: 18px; font-weight: bold;">Kontak Langsung:</p>
        <ul style="margin-top: 10px; font-size: 16px; list-style-type: none; padding-left: 0;">
            <li><strong>Email:</strong> khanifadnan57@gmail.com</li>
            <li><strong>Telepon:</strong> (+62) 896-5802-2825</li>
        </ul>
    </div>
</div>

<?php include 'footer.php'; ?>
