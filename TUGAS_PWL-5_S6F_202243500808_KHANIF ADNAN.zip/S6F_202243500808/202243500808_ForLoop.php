<?php include 'header.php'; ?>
<?php include 'sidebar.php'; ?>

<div class="content">
    <?php
    //inisialisasi nilai awal
    //jalankan selama memenuhi sayarat
    //execute setelah menjalankan blok
    for ($i = 0; $i < 10; $i++) {
        echo $i;
    }

    //0123456789
    ?>
</div>

<?php include 'footer.php'; ?>