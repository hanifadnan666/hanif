<aside class="sidebar" style="padding: 20px;">
    <h3>List Latihan</h3>

    <ul style="list-style: none; padding: 0; margin: 0;">

        <li><a href="http://localhost/S6F_202243500808/202243500808_Biodata.php">Biodata</a></li>
        <li><a href="http://localhost/S6F_202243500808/202243500808_HelloWorld.php">Hello World</a></li>
        <li><a href="http://localhost/S6F_202243500808/202243500808_Konstanta.php">Konstanta</a></li>
        <li><a href="http://localhost/S6F_202243500808/202243500808_Object.php">Object</a></li>
        <li><a href="http://localhost/S6F_202243500808/202243500808_OperatorAritmatika.php">Operator Aritmatika</a></li>
        <li><a href="http://localhost/S6F_202243500808/202243500808_OperatorPerbandingan.php">Operator Perbandingan</a></li>
        <li><a href="http://localhost/S6F_202243500808/202243500808_OperatorString.php">Operator String</a></li>
        <li><a href="http://localhost/S6F_202243500808/202243500808_Variabel.php">Variabel</a></li>
        <li><a href="http://localhost/S6F_202243500808/202243500808_KondisiIf.php">Kondisi If</a></li>
        <li><a href="http://localhost/S6F_202243500808/202243500808_KondisiElseIf.php">Kondisi ElseIf</a></li>
        <li><a href="http://localhost/S6F_202243500808/202243500808_KondisiSwitch.php">Kondisi Switch</a></li>
        <li><a href="http://localhost/S6F_202243500808/202243500808_WhileLoop.php">While Loop</a></li>
        <li><a href="http://localhost/S6F_202243500808/202243500808_DoWhileLoop.php">Do While Loop</a></li>
        <li><a href="http://localhost/S6F_202243500808/202243500808_ForLoop.php">For Loop</a></li>
        <li><a href="http://localhost/S6F_202243500808/202243500808_ForeachLoop.php">Foreach Loop</a></li>
        <li><a href="http://localhost/S6F_202243500808/202243500808_Function.php">Function</a></li>
        <li><a href="http://localhost/S6F_202243500808/202243500808_FunctionCallByValue.php">Function Call By Value</a></li>
        <li><a href="http://localhost/S6F_202243500808/202243500808_FunctionByRef.php">Function By Ref</a></li>
        <li><a href="http://localhost/S6F_202243500808/202243500808_FunctionParameter.php">Function Parameter</a></li>
        <li><a href="http://localhost/S6F_202243500808/202243500808_FunctionParameterDefault.php">Function Parameter Default</a></li>
        <li><a href="http://localhost/S6F_202243500808/202243500808_Soal1.php">Soal 1</a></li>
        <li><a href="http://localhost/S6F_202243500808/202243500808_Soal2.php">Soal 2</a></li>
        <li><a href="http://localhost/S6F_202243500808/202243500808_Soal3.php">Soal 3</a></li>
    </ul>
</aside>