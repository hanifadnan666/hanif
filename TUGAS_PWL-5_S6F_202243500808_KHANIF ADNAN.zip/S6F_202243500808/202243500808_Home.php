<?php include 'header.php'; ?>
<?php include 'sidebar.php'; ?>

<div class="container">
    <div class="container-navbar">
    </div>

    <div class="main-content">
        <h3>Halo! Senang melihat Anda di sini!</h3>

    </div>
</div>

<?php include 'footer.php'; ?>
