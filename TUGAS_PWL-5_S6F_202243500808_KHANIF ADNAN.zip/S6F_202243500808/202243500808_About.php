<?php include 'header.php'; ?>
<?php include 'sidebar.php'; ?>

<div class="container">
    <h1 class="page-title">Tentang Website Ini</h1>

    <div class="about-box" style="padding: 20px; line-height: 1.8;">

        <p>Website ini lahir sebagai arena belajar seru bagi saya yang ingin mengasah skill pemrograman web dengan <strong>PHP</strong>. 
        </p>

        <h2 class="section-title" style="margin-top: 30px;">Mengapa Website Ini Ada?</h2>
        <ul style="margin-left: 20px;">
            <li>Wadah latihan coding harian dan dokumentasi perjalanan belajar saya.</li>
            <li>untuk kebutuhan tugas kuliah.</li>
        </ul>

        <h2 class="section-title" style="margin-top: 30px;">Siapa di Balik Website Ini?</h2>
        <p>Perkenalkan, saya <strong>Khanif Adnan</strong> — mahasiswa aktif Teknik Informatika di UNINDRA, sekaligus penggemar ngoding, mancing, dan joging. 
        Website ini adalah salah satu proyek latihan mandiri saya untuk terus berkembang.</p>

    </div>
</div>

<?php include 'footer.php'; ?>
