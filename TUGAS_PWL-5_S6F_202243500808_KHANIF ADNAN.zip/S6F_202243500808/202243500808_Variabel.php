<?php include 'header.php'; ?>
<?php include 'sidebar.php'; ?>

<div class="content">
    <?php
    $nama = "Upin";
    $usia = 5;
    $hobi = array("membaca", "Mewarnai");

    echo "$nama berusia $usia tahun <br/>";
    // Upin berusia 5 tahun
    echo "Hobinya : $hobi[0], $hobi[1]";
    // Hobinya : membaca, mewarnai
    ?>
</div>

<?php include 'footer.php'; ?>